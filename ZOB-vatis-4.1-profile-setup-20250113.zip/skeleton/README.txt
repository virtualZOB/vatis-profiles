How to Leverage:

1. Ensure you are on vATIS 4.1 or higher.  The latest can be found at https://vatis.app/

2. Import each of the profiles in this folder

3. Close and reopen vATIS


This will pull down the latest profiles from our repository.  They will be automatically updated each time the facilities team updates them.  


Notes:
- Do not make new composites on your computer.  If you find the need for a new composite, please put the ask in https://discord.com/channels/450744534989668372/1085720737651904582 selecting the "Facilities" Tag

- When you are using 4.1+ you will also see the letters of any other active ATIS profile from other controllers within the ARTCC in your view.